import type { StreamPayload, WidgetController, WidgetFactory } from '../../web/src/types';

type TwitchPlatform = 'twitch' | 'YouTube' | 'web';

type LastState = {
  channel: string;
  platform: TwitchPlatform;
};

declare global {
  interface Window {
    Twitch?: any;
    YT?: any;
    onYouTubeIframeAPIReady?: () => void;
    _twitchEmbedCallbacks?: Array<() => void>;
  }
}

const TWITCH_SDK_URL = 'https://embed.twitch.tv/embed/v1.js';
let twitchReadyPromise: Promise<void> | null = null;
let youtubeReadyPromise: Promise<void> | null = null;

export const createTwitchstreamController: WidgetFactory = ({ root, widget }) => {
  return new TwitchstreamController(root, widget.id);
};

class TwitchstreamController implements WidgetController {
  private root: HTMLElement;
  private widgetId: string;
  private statusEl: HTMLElement | null;
  private container: HTMLElement;
  private twitchEmbed: any = null;
  private twitchPlayer: any = null;
  private ytPlayer: any = null;
  private playerReady = false;
  private currentPlatform: TwitchPlatform | null = null;
  private currentChannel: string | null = null;
  private destroyed = false;
  private lastStateKey: string;
  private twitchRetryTimer: ReturnType<typeof setTimeout> | null = null;
  private twitchReloadTimer: ReturnType<typeof setTimeout> | null = null;
  private twitchWatchdogTimer: ReturnType<typeof setTimeout> | null = null;
  private reloadLocked = false;
  private firstOfflineTs: number | null = null;
  private lastPlayTs: number | null = null;

  constructor(root: HTMLElement, widgetId: string) {
    this.root = root;
    this.widgetId = widgetId;
    this.lastStateKey = `twitchstream:last:${widgetId}`;
    this.statusEl = this.root.querySelector('.stream-status');
    // Hide status element entirely to avoid flashing messages in the UI.
    if (this.statusEl) {
      this.statusEl.style.display = 'none';
    }
    this.container = this.ensureContainer();
    this.setStatus('');
  }

  update(payload?: StreamPayload) {
    if (this.destroyed) return;
    const { channel, platform } = this.resolveState(payload);

    if (!channel) {
      this.setStatus('No channel provided');
      this.destroyPlayers(true);
      return;
    }

    const nextPlatform: TwitchPlatform = platform ?? 'twitch';

    if (nextPlatform !== this.currentPlatform) {
      this.destroyPlayers(true);
    }

    this.currentPlatform = nextPlatform;
    this.currentChannel = channel;

    switch (nextPlatform) {
      case 'twitch':
        this.showTwitch(channel);
        break;
      case 'YouTube':
        this.showYouTube(channel);
        break;
      case 'web':
        this.showWeb(channel);
        break;
      default:
        this.showWeb(channel);
    }

    this.saveLastState(channel, nextPlatform);
  }

  destroy() {
    this.destroyed = true;
    this.destroyPlayers(true);
  }

  private resolveState(payload?: StreamPayload): { channel: string | null; platform: TwitchPlatform | null } {
    const data = (payload?.data ?? {}) as Record<string, any>;
    let channel = data.channel ?? data.url ?? data.id ?? data.stream ?? '';
    let platform = data.platform ?? data.source ?? '';

    if (!platform && payload?.type && ['twitch', 'YouTube', 'web'].includes(payload.type)) {
      platform = payload.type;
    }

    const last = this.loadLastState();
    if (!channel && last?.channel) channel = last.channel;
    if (!platform && last?.platform) platform = last.platform;

    return {
      channel: channel || null,
      platform: this.normalizePlatform(platform)
    };
  }

  private normalizePlatform(value?: string): TwitchPlatform | null {
    const raw = (value ?? '').toLowerCase();
    if (raw === 'twitch') return 'twitch';
    if (raw === 'youtube' || raw === 'yt') return 'YouTube';
    if (raw === 'web' || raw === 'page') return 'web';
    return null;
  }

  private ensureContainer(): HTMLElement {
    const selector = `[data-widget-id='${this.widgetId}']`;
    const existing = this.root.querySelector(selector) as HTMLElement | null;
    if (existing) return existing;

    // Avoid creating a container before the template is in place; if missing, create and mark it so a later
    // template render with the same data-widget-id will reuse it instead of replacing it.
    const el = document.createElement('div');
    el.id = `video-embed-${this.widgetId}`;
    el.className = 'video-embed';
    el.dataset.widgetId = this.widgetId;
    el.style.setProperty('visibility', 'visible', 'important');
    el.style.setProperty('opacity', '1', 'important');
    el.style.setProperty('display', 'block', 'important');
    this.root.appendChild(el);
    return el;
  }

  private log(message: string, meta?: Record<string, any>) {
    try {
      if (meta) console.log('[twitchstream]', message, meta);
      else console.log('[twitchstream]', message);
    } catch (_) {
      /* noop */
    }
  }

  private setStatus(text: string) {
    if (!this.statusEl) return;
    // keep display none so it never shows
    this.statusEl.style.display = 'none';
  }

  private clearTwitchRetry() {
    if (this.twitchRetryTimer) {
      clearTimeout(this.twitchRetryTimer);
      this.twitchRetryTimer = null;
    }
  }

  private clearTwitchReloadTimers() {
    if (this.twitchReloadTimer) {
      clearTimeout(this.twitchReloadTimer);
      this.twitchReloadTimer = null;
    }
    if (this.twitchWatchdogTimer) {
      clearTimeout(this.twitchWatchdogTimer);
      this.twitchWatchdogTimer = null;
    }
    this.reloadLocked = false;
  }

  private async tryPlay(player: any) {
    if (!player?.play) return;

    // Avoid sending commands before Twitch marks the player ready.
    if (!this.playerReady) return;

    this.clearTwitchRetry();

    const attempt = async (muted: boolean) => {
      try {
        if (muted) player.setMuted?.(true);
        await player.play();
        return true;
      } catch (_) {
        return false;
      }
    };

    // Try muted first to satisfy autoplay policies.
    if (await attempt(true)) {
      // Unmute shortly after playback starts.
      setTimeout(() => player.setMuted?.(false), 500);
      return;
    }
    const mutedWorked = await attempt(false);
    if (mutedWorked) {
      // Give the player a moment before restoring audio; some browsers require a delay.
      setTimeout(() => player.setMuted?.(false), 400);
    }

    // If both attempts failed, schedule a one-shot retry to mimic the old dashboard behavior.
    this.twitchRetryTimer = setTimeout(() => {
      if (this.destroyed) return;
      // this.log('retrying play after block');
      void attempt(true);
    }, 1200);
  }

  private ensureEmbedVisible() {
    const container = this.container;
    container.style.setProperty('visibility', 'visible', 'important');
    container.style.setProperty('opacity', '1', 'important');
    container.style.setProperty('display', 'block', 'important');
    container.style.setProperty('pointer-events', 'auto', 'important');
    if (!container.style.height || container.style.height === '0px') {
      container.style.setProperty('height', '100%', 'important');
    }
    if (!container.style.minHeight || container.style.minHeight === '0px') {
      container.style.setProperty('min-height', '360px', 'important');
    }
    if (!container.style.width || container.style.width === '0px') {
      container.style.setProperty('width', '100%', 'important');
    }
    if (!container.style.position) {
      container.style.setProperty('position', 'relative', 'important');
    }
  }

  private forceContainerVisible() {
    const container = this.container;
    container.style.setProperty('visibility', 'visible', 'important');
    container.style.setProperty('opacity', '1', 'important');
    container.style.setProperty('display', 'block', 'important');
    if (!container.style.height || container.style.height === '0px') {
      container.style.setProperty('height', '100%', 'important');
    }
    if (!container.style.minHeight || container.style.minHeight === '0px') {
      container.style.setProperty('min-height', '360px', 'important');
    }
    if (!container.style.width || container.style.width === '0px') {
      container.style.setProperty('width', '100%', 'important');
    }
    if (!container.style.position) {
      container.style.setProperty('position', 'relative', 'important');
    }
  }

  private ensureContainerSize() {
    const rect = this.container.getBoundingClientRect();
    const minH = rect.height && rect.height > 0 ? rect.height : 360;
    const minW = rect.width && rect.width > 0 ? rect.width : 640;
    if (!this.container.style.height || this.container.style.height === '0px') {
      this.container.style.height = `${Math.max(minH, 360)}px`;
    }
    if (!this.container.style.width || this.container.style.width === '0px') {
      this.container.style.width = `${Math.max(minW, 640)}px`;
    }
  }

  private async ensureContainerReadyForEmbed(): Promise<void> {
    this.forceContainerVisible();
    this.ensureContainerSize();
    await new Promise(requestAnimationFrame);
    const rect = this.container.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) {
      this.ensureContainerSize();
      await new Promise(requestAnimationFrame);
    }
    const finalRect = this.container.getBoundingClientRect();
    if (finalRect.width <= 0 || finalRect.height <= 0) {
      this.container.style.width = '960px';
      this.container.style.height = '540px';
    }
  }

  private destroyPlayers(clearHtml = false) {
    this.clearTwitchRetry();
    this.clearTwitchReloadTimers();
    if (this.playerReady) {
      try {
        this.twitchPlayer?.pause?.();
      } catch (_) {
        /* noop */
      }
    }
    try {
      this.twitchEmbed?.destroy?.();
    } catch (_) {
      /* noop */
    }
    this.twitchPlayer = null;
    this.twitchEmbed = null;
    this.playerReady = false;

    try {
      this.ytPlayer?.destroy?.();
    } catch (_) {
      /* noop */
    }
    this.ytPlayer = null;

    if (clearHtml) {
      this.container.innerHTML = '';
    }
  }

  private async ensureTwitchReady(): Promise<void> {
    if (window.Twitch?.Embed) return;
    if (!twitchReadyPromise) {
      twitchReadyPromise = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = TWITCH_SDK_URL;
        script.async = true;
        script.onload = () => resolve();
        script.onerror = err => reject(err);
        document.head.appendChild(script);
      });
    }
    await twitchReadyPromise;
  }

  private async ensureYouTubeApi(): Promise<void> {
    if (window.YT?.Player) return;
    if (!youtubeReadyPromise) {
      youtubeReadyPromise = new Promise(resolve => {
        window.onYouTubeIframeAPIReady = () => resolve();
        if (document.querySelector("script[src='https://www.youtube.com/iframe_api']")) return;
        const tag = document.createElement('script');
        tag.src = 'https://www.youtube.com/iframe_api';
        document.head.appendChild(tag);
      });
    }
    await youtubeReadyPromise;
  }

  private async showTwitch(channel: string) {
    this.setStatus('Loading Twitch…');
    await this.ensureTwitchReady();
    if (this.destroyed) return;

    // If we already have a live embed for this channel, reuse it instead of rebuilding.
    if (this.twitchEmbed && this.currentPlatform === 'twitch' && this.currentChannel === channel) {
      const existing = this.twitchEmbed.getPlayer?.();
      if (existing) {
        this.twitchPlayer = existing;
        this.playerReady = true;
        this.setStatus('');
        void this.tryPlay(existing);
        return;
      }
    }

    this.ensureEmbedVisible();

    const parentHosts = this.resolveParentHosts();
    const targetId = this.container.id || `video-embed-${this.widgetId}`;

    if (this.twitchEmbed) {
      const player = this.twitchEmbed.getPlayer?.();
      if (player?.setChannel) {
        this.log('reusing twitch player; switching channel', { channel });
        player.setChannel(channel);
        this.playerReady = true;
        void this.tryPlay(player);
        this.twitchPlayer = player;
        this.setStatus('');
        this.armWatchdog(channel);
        return;
      }
      this.destroyPlayers(true);
    }

    this.container.innerHTML = '';

    await this.ensureContainerReadyForEmbed();
    const rect = this.container.getBoundingClientRect();
    const width = Math.max(320, Math.floor(rect.width || this.container.clientWidth || 320));
    const height = Math.max(240, Math.floor(rect.height || this.container.clientHeight || 240));

    this.log('building twitch embed', { channel, width, height });
    const embed = new window.Twitch.Embed(targetId, {
      width,
      height,
      channel,
      layout: 'video',
      parent: parentHosts,
      autoplay: true,
      muted: true,
      allowfullscreen: true,
      theme: 'dark'
    });

    this.twitchEmbed = embed;
    this.playerReady = false;
    this.registerTwitchEvents(embed, channel);
    this.armWatchdog(channel);
  }

  private registerTwitchEvents(embed: any, initialChannel: string) {
    const twitch = window.Twitch;
    if (!twitch?.Embed || !embed?.addEventListener) return;

    const wire = (evt: any, handler: (player: any) => void) => {
      if (!evt) return;
      try {
        embed.addEventListener(evt, () => {
          const player = embed.getPlayer?.();
          if (player) this.twitchPlayer = player;
          handler(player);
        });
      } catch (_) {
        /* noop */
      }
    };

    wire(twitch.Embed.VIDEO_READY, player => {
      this.log('video ready', { channel: player?.getChannel?.() || initialChannel });
      this.setStatus('');
      this.playerReady = true;
      void this.tryPlay(player);
      this.armWatchdog(initialChannel);
    });

    wire(twitch.Embed.VIDEO_PLAY, () => {
      this.log('embed VIDEO_PLAY fired (online)');
      this.setStatus('');
      this.clearTwitchRetry();
      this.notePlay();
    });

    wire(twitch.Embed.VIDEO_PAUSE, () => {
      this.log('embed VIDEO_PAUSE');
      this.setStatus('Paused');
    });

    // Forward key player events to improve reliability (mirrors legacy widget logic)
    wire(twitch.Player?.READY, player => {
      this.log('player READY');
      this.playerReady = true;
      void this.tryPlay(player);
      this.armWatchdog(initialChannel);
    });

    wire(twitch.Player?.PLAY, player => {
      this.log('player PLAY', { channel: player?.getChannel?.() || initialChannel });
      this.clearTwitchRetry();
      void this.tryPlay(player);
      const liveChannel = player?.getChannel?.() || initialChannel;
      if (liveChannel) this.saveLastState(liveChannel, 'twitch');
      this.notePlay();
    });

    wire(twitch.Player?.PLAYING, player => {
      this.log('player PLAYING', { channel: player?.getChannel?.() || initialChannel });
      this.clearTwitchRetry();
      const liveChannel = player?.getChannel?.() || initialChannel;
      if (liveChannel) this.saveLastState(liveChannel, 'twitch');
      this.notePlay();
    });

    wire(twitch.Player?.ONLINE, player => {
      this.log('player ONLINE', { channel: player?.getChannel?.() || initialChannel });
      this.clearTwitchRetry();
      void this.tryPlay(player);
      const liveChannel = player?.getChannel?.() || initialChannel;
      if (liveChannel) this.saveLastState(liveChannel, 'twitch');
      this.notePlay();
    });

    wire(twitch.Player?.PLAYBACK_BLOCKED, player => {
      this.log('player PLAYBACK_BLOCKED');
      this.handlePlaybackBlocked(player);
    });

    wire(twitch.Player?.OFFLINE, player => {
      this.log('player OFFLINE', { channel: player?.getChannel?.() || initialChannel });
      const liveChannel = player?.getChannel?.() || initialChannel;
      this.handleOffline(liveChannel);
    });
  }

  private handlePlaybackBlocked(player: any) {
    this.log('playback blocked; attempting muted play');
    try {
      player?.setMuted?.(true);
    } catch (_) {
      /* noop */
    }
    void this.tryPlay(player);
  }

  private handleOffline(channel?: string | null) {
    this.log('offline event', { channel });
    // Previously reloaded on offline; this could trigger Twitch autoplay checks during rebuild.
    // Instead, keep the current player alive and rely on Twitch's own reconnect behavior.
  }

  private notePlay() {
    this.firstOfflineTs = null;
    this.lastPlayTs = Date.now();
    this.clearTwitchReloadTimers();
  }

  private armWatchdog(channel: string) {
    if (this.currentPlatform !== 'twitch') return;
    // Disable watchdog-driven reloads to avoid rebuilding the embed mid-session.
  }

  private startReload(channel: string, delayMs = 2000, destroyFirst = false) {
    if (this.currentPlatform !== 'twitch') return;
    // Reloads are disabled to prevent Twitch from flagging autoplay during rebuilds.
  }

  private async showYouTube(videoId: string) {
    this.setStatus('Loading YouTube…');
    await this.ensureYouTubeApi();
    if (this.destroyed) return;

    const normalizedId = this.extractYouTubeId(videoId);

    this.destroyPlayers(true);
    const frameId = `${this.container.id || 'video-embed'}-yt`;
    const mount = document.createElement('div');
    mount.id = frameId;
    this.container.appendChild(mount);

    this.ytPlayer = new window.YT.Player(frameId, {
      videoId: normalizedId,
      height: '100%',
      width: '100%',
      playerVars: { autoplay: 1 },
      events: {
        onReady: (event: { target?: any }) => this.fixYouTubeIframePosition(event?.target)
      }
    });

    this.setStatus('');
  }

  private showWeb(url: string) {
    this.setStatus('');
    this.destroyPlayers(true);
    const iframe = document.createElement('iframe');
    iframe.src = url;
    iframe.frameBorder = '0';
    iframe.allowFullscreen = true;
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';
    iframe.style.display = 'block';
    this.container.appendChild(iframe);
  }

  private extractYouTubeId(raw: string): string {
    try {
      const url = new URL(raw);
      if (url.hostname.includes('youtu.be')) {
        return url.pathname.replace('/', '') || raw;
      }
      if (url.searchParams.has('v')) {
        return url.searchParams.get('v') ?? raw;
      }
      const parts = url.pathname.split('/').filter(Boolean);
      if (parts[0] === 'embed' && parts[1]) return parts[1];
      return raw;
    } catch (_) {
      return raw;
    }
  }

  private fixYouTubeIframePosition(player: any) {
    if (!player?.getIframe) return;
    const iframe = player.getIframe();
    if (!iframe) return;
    iframe.style.position = 'absolute';
    iframe.style.top = '0';
    iframe.style.left = '0';
    iframe.style.margin = '0';
    iframe.style.transform = 'translateY(0)';
    iframe.style.width = '100%';
    iframe.style.height = '100%';
  }

  // private resolveParentHosts(): string[] {
  //   const host = window.location.hostname || window.location.host || 'localhost';
  //   const altHost = window.location.host?.split(':')[0];
  //   return [host, altHost, 'localhost', '127.0.0.1']
  //     .filter((h, idx, arr) => h && arr.indexOf(h) === idx) as string[];
  // }
  private resolveParentHosts(): string[] {
    const host = window.location.hostname || window.location.host || 'localhost';
    const altHost = window.location.host?.split(':')[0];
    return [host, altHost, 'localhost', '127.0.0.1']
      .filter((h, idx, arr) => h && arr.indexOf(h) === idx) as string[];
  }

  private loadLastState(): LastState | null {
    try {
      const stored = localStorage.getItem(this.lastStateKey);
      return stored ? (JSON.parse(stored) as LastState) : null;
    } catch (_) {
      return null;
    }
  }

  private saveLastState(channel: string, platform: TwitchPlatform) {
    if (!channel) return;
    try {
      const payload: LastState = { channel, platform };
      localStorage.setItem(this.lastStateKey, JSON.stringify(payload));
    } catch (_) {
      /* noop */
    }
  }
}
