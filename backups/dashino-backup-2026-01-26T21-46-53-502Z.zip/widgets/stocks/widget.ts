import type { StreamPayload, WidgetController, WidgetFactory } from '../../web/src/types';

type Bindable = HTMLElement & { dataset: { bind?: string; bindClass?: string } };

const ET_ZONE = 'America/New_York';
const WORK_START_MIN = 9 * 60 + 30; // 09:30
const WORK_END_MIN = 17 * 60; // 17:00

export const createStocksController: WidgetFactory = ({ root }) => {
  return new StocksController(root);
};

class StocksController implements WidgetController {
  private root: HTMLElement;
  private visibilityTimer: number | null = null;

  constructor(root: HTMLElement) {
    this.root = root;
    this.applyVisibility();
    this.visibilityTimer = window.setInterval(() => this.applyVisibility(), 60_000);
  }

  update(payload?: StreamPayload) {
    const data = (payload?.data ?? payload ?? {}) as Record<string, unknown>;
    this.bindText(data);
    this.bindClasses(data);
    this.applyVisibility();
  }

  destroy() {
    if (this.visibilityTimer) {
      clearInterval(this.visibilityTimer);
      this.visibilityTimer = null;
    }
  }

  private applyVisibility() {
    const show = shouldShowChange();
    const nodes = this.root.querySelectorAll('[data-bind^="change"]');
    nodes.forEach(el => {
      if (!(el instanceof HTMLElement)) return;
      el.classList.toggle('hide-change', !show);
    });
  }

  private bindText(data: Record<string, unknown>) {
    const nodes = this.root.querySelectorAll('[data-bind]');
    nodes.forEach(node => {
      const el = node as Bindable;
      const key = el.dataset.bind;
      if (!key) return;
      const value = data[key];
      if (value === undefined || value === null) return;
      el.textContent = String(value);
    });
  }

  private bindClasses(data: Record<string, unknown>) {
    const nodes = this.root.querySelectorAll('[data-bind-class]');
    nodes.forEach(node => {
      const el = node as Bindable;
      const key = el.dataset.bindClass;
      if (!key) return;
      const className = data[key];
      el.classList.remove('pos', 'neg');
      if (typeof className === 'string' && className.length > 0) {
        el.classList.add(className);
      }
    });
  }
}

function shouldShowChange(): boolean {
  try {
    const now = new Date();
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: ET_ZONE,
      weekday: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    }).formatToParts(now);

    const weekday = parts.find(p => p.type === 'weekday')?.value ?? '';
    const hour = parseInt(parts.find(p => p.type === 'hour')?.value ?? '0', 10);
    const minute = parseInt(parts.find(p => p.type === 'minute')?.value ?? '0', 10);
    const total = hour * 60 + minute;

    const isWeekend = weekday === 'Sat' || weekday === 'Sun';
    const isWorkHours = total >= WORK_START_MIN && total < WORK_END_MIN;
    return !isWeekend && isWorkHours;
  } catch (e) {
    console.error('stocks widget visibility check failed', e);
    return true;
  }
}
