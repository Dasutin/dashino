import type { StreamPayload, WidgetController, WidgetFactory } from '../../web/src/types';

type HourPoint = {
  hour: string;
  temp: string;
  emoji: string;
};

type HourlyData = {
  points?: HourPoint[];
};

const PADDING_TOP = 15;
const PADDING_BOTTOM = 40;

export const createHourlyController: WidgetFactory = ({ root, widget }) => {
  return new HourlyController(root, widget.id);
};

class HourlyController implements WidgetController {
  private root: HTMLElement;
  private widgetId: string;
  private svg: SVGSVGElement;
  private labels: HTMLElement;
  private hoursRow: HTMLElement;

  constructor(root: HTMLElement, widgetId: string) {
    this.root = root;
    this.widgetId = widgetId;
    this.svg = this.requireSvgElement('line-graph');
    this.labels = this.requireElement('labels-overlay');
    this.hoursRow = this.requireElement('hour-row');
  }

  update(payload?: StreamPayload) {
    const data = (payload?.data ?? payload ?? {}) as HourlyData;
    const points = Array.isArray(data.points) ? data.points : [];

    this.clear();

    if (points.length < 2) return;
    const rect = this.svg.getBoundingClientRect();
    const graphWidth = rect.width;
    const graphHeight = rect.height;
    if (!graphWidth || !graphHeight) return;

    const height = graphHeight - (PADDING_TOP + PADDING_BOTTOM);
    const stepX = graphWidth / points.length;

    const temps = points.map(p => Number(p.temp)).filter(n => Number.isFinite(n));
    if (temps.length === 0) return;

    const minTemp = Math.min(...temps);
    const maxTemp = Math.max(...temps);
    const range = maxTemp - minTemp || 1;

    const gradientId = `temp-gradient-${this.widgetId}`;
    const gradient = this.buildGradient(points, gradientId, range, minTemp);
    this.svg.appendChild(gradient.defs);

    this.buildHours(points);

    const coords = points.map((p, i) => {
      const x = i * stepX + stepX / 2;
      const y = PADDING_TOP + (1 - (Number(p.temp) - minTemp) / range) * height;
      return { x, y };
    });

    const line = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
    line.setAttribute('fill', 'none');
    line.setAttribute('stroke', `url(#${gradientId})`);
    line.setAttribute('stroke-width', '2');
    line.setAttribute('stroke-linecap', 'round');
    line.setAttribute(
      'points',
      coords
        .map(({ x, y }) => `${x},${y}`)
        .join(' ')
    );
    this.svg.appendChild(line);

    this.buildLabels(points, coords);
  }

  destroy() {
    this.clear();
  }

  private requireElement(className: string, tagName?: string): HTMLElement {
    const el = this.root.querySelector(`.${className}`);
    if (!el) {
      const created = document.createElement(tagName || 'div');
      created.className = className;
      this.root.appendChild(created);
      return created;
    }
    return el as HTMLElement;
  }

  private requireSvgElement(className: string): SVGSVGElement {
    const el = this.root.querySelector(`.${className}`);
    if (el instanceof SVGSVGElement) return el;
    const created = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    created.classList.add(className);
    this.root.appendChild(created);
    return created;
  }

  private clear() {
    this.svg.innerHTML = '';
    this.labels.innerHTML = '';
    this.hoursRow.innerHTML = '';
  }

  private buildHours(points: HourPoint[]) {
    points.forEach(p => {
      const hourLabel = document.createElement('div');
      hourLabel.textContent = p.hour;
      this.hoursRow.appendChild(hourLabel);
    });
  }

  private buildGradient(points: HourPoint[], id: string, range: number, minTemp: number) {
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    const gradient = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient');
    gradient.id = id;
    gradient.setAttribute('x1', '0%');
    gradient.setAttribute('y1', '0%');
    gradient.setAttribute('x2', '100%');
    gradient.setAttribute('y2', '0%');

    points.forEach((p, i) => {
      const stop = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
      const offset = (i / Math.max(points.length - 1, 1)) * 100;
      stop.setAttribute('offset', `${offset}%`);
      stop.setAttribute('stop-color', this.colorForTemp(Number(p.temp)));
      gradient.appendChild(stop);
    });

    defs.appendChild(gradient);
    return { defs, gradient };
  }

  private buildLabels(points: HourPoint[], coords: Array<{ x: number; y: number }>) {
    points.forEach((p, i) => {
      const coord = coords[i];
      const wrapper = document.createElement('div');
      wrapper.className = 'label-set';
      wrapper.style.left = `${coord.x}px`;
      wrapper.style.top = `${coord.y}px`;

      const emoji = document.createElement('div');
      emoji.className = 'emoji';
      emoji.textContent = p.emoji;

      const temp = document.createElement('div');
      temp.className = 'temp';
      temp.textContent = p.temp;
      temp.style.color = this.colorForTemp(Number(p.temp));

      wrapper.appendChild(emoji);
      wrapper.appendChild(temp);
      this.labels.appendChild(wrapper);
    });
  }

  private colorForTemp(temp: number) {
    if (!Number.isFinite(temp)) return 'hsl(200, 0%, 70%)';
    const t = Math.round(temp);
    let hue: number;
    if (t <= 30) hue = 240;
    else if (t <= 40) hue = 240 - ((t - 30) / 10) * 30;
    else if (t <= 50) hue = 210 - ((t - 40) / 10) * 30;
    else if (t <= 60) hue = 180 - ((t - 50) / 10) * 60;
    else if (t <= 70) hue = 120 - ((t - 60) / 10) * 60;
    else if (t <= 80) hue = 60 - ((t - 70) / 10) * 30;
    else if (t <= 90) hue = 30 - ((t - 80) / 10) * 30;
    else hue = 0;
    return `hsl(${Math.round(hue)}, 100%, 60%)`;
  }
}
