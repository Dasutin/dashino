import type { StreamPayload, WidgetController, WidgetFactory } from '../../web/src/types';

type EvData = {
  battery?: number;
  current?: string;
  time?: string;
  state?: string;
};

export const createEvController: WidgetFactory = ({ root, widget }) => {
  return new EvController(root, widget.id);
};

class EvController implements WidgetController {
  private root: HTMLElement;
  private widgetContainer: HTMLElement | null;
  private meterFill: SVGCircleElement | null;
  private meterValue: SVGTextElement | null;
  private rangeEl: HTMLElement | null;
  private timeEl: HTMLElement | null;
  private circumference: number;

  constructor(root: HTMLElement, widgetId: string) {
    this.root = root;
    this.widgetContainer = root.closest('.widget');
    this.meterFill = root.querySelector('.meter-fill');
    this.meterValue = root.querySelector('.meter-value');
    this.rangeEl = root.querySelector('.range');
    this.timeEl = root.querySelector('.time');
    const r = this.meterFill?.r.baseVal.value || 52;
    this.circumference = 2 * Math.PI * r;
  }

  update(payload?: StreamPayload) {
    const data = (payload?.data ?? payload ?? {}) as EvData;
    const battery = Number(data.battery ?? NaN);
    const percent = Number.isFinite(battery) ? Math.max(0, Math.min(100, Math.round(battery))) : 0;
    const state = this.normalizeState((data.state || 'idle').toString());

    this.setStateClass(state);
    this.updateMeter(percent);
    if (this.rangeEl && data.current !== undefined) this.rangeEl.textContent = String(data.current);
    if (this.timeEl) this.timeEl.textContent = data.time ? String(data.time) : '';
  }

  destroy() {
    // no-op
  }

  private setStateClass(state: string) {
    const classList = this.root.classList;
    Array.from(classList)
      .filter(cls => cls.startsWith('ev-state-'))
      .forEach(cls => classList.remove(cls));
    classList.add(`ev-state-${state}`);

    if (this.widgetContainer) {
      const containerList = this.widgetContainer.classList;
      Array.from(containerList)
        .filter(cls => cls.startsWith('ev-state-'))
        .forEach(cls => containerList.remove(cls));
      containerList.add(`ev-state-${state}`);
    }
  }

  private normalizeState(state: string): string {
    const s = (state || '').toString().trim().toLowerCase();
    if (s.includes('charg')) return 'charging';
    if (s.includes('unplug')) return 'unplugged';
    if (s.includes('connect')) return 'connected';
    return 'idle';
  }

  private updateMeter(percent: number) {
    if (this.meterValue) this.meterValue.textContent = `${percent}%`;
    if (!this.meterFill) return;
    const dash = (percent / 100) * this.circumference;
    this.meterFill.setAttribute('stroke-dasharray', `${dash} ${this.circumference}`);
    const color = percent >= 80 ? '#22c55e' : percent >= 40 ? '#84cc16' : '#f97316';
    this.meterFill.setAttribute('stroke', color);
  }
}
