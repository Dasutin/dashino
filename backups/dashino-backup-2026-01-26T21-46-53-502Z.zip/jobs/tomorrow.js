const HA_BASE_URL = process.env.HA_BASE_URL || 'http://localhost:8123';
const HA_TOKEN = process.env.HA_TOKEN || 'REPLACE_WITH_HA_TOKEN';
const HA_TIMEOUT_MS = 8000;
const FORECAST_ENTITY = 'weather.tomorrow_io_home_daily';
const POLLEN_API_KEY = process.env.POLLEN_API_KEY;

const SNOW_URL = 'https://api.weather.gov/gridpoints/ALY/66,66';

function tempClass(temp) {
  const t = Number(temp);
  if (!Number.isFinite(t)) return '';
  if (t <= 0) return 'temp-0';
  if (t <= 10) return 'temp-1';
  if (t <= 20) return 'temp-2';
  if (t <= 30) return 'temp-3';
  if (t <= 40) return 'temp-4';
  if (t <= 50) return 'temp-5';
  if (t <= 60) return 'temp-6';
  if (t <= 70) return 'temp-7';
  if (t <= 80) return 'temp-8';
  if (t <= 90) return 'temp-9';
  if (t <= 100) return 'temp-10';
  return 'temp-11';
}

function emojiFor(condition) {
  const c = (condition || '').toLowerCase();
  if (c === 'sunny' || c === 'clear-day') return '☀️';
  if (c === 'clear-night') return '🌙';
  if (c === 'cloudy') return '☁️';
  if (c === 'partlycloudy' || c === 'partly-cloudy-day' || c === 'partly-cloudy-night') return '⛅';
  if (c === 'rainy' || c === 'rain') return '🌧️';
  if (c === 'pouring') return '💧';
  if (c === 'snowy' || c === 'snow') return '❄️';
  if (c === 'fog') return '🌫️';
  if (c === 'windy') return '💨';
  if (c === 'hail' || c === 'snowy-rainy') return '🌨️';
  if (c === 'lightning' || c === 'lightning-rainy' || c === 'thunderstorm') return '🌩️';
  return '🔍';
}

function arrowFor(level) {
  const l = (level || '').toLowerCase();
  if (l === 'very high') return '⬆️⬆️';
  if (l === 'high') return '⬆️';
  if (l === 'moderate') return '➖';
  if (l === 'low') return '⬇️';
  if (l === 'very low') return '⬇️⬇️';
  return '?';
}

function inchesFrom(value, unitCode) {
  if (value === null || value === undefined) return null;
  const v = Number(value);
  if (!Number.isFinite(v)) return null;
  if (/wmoUnit:(in|inch)/.test(unitCode || '')) return v;
  if (/wmoUnit:mm/.test(unitCode || '')) return v / 25.4;
  if (/wmoUnit:cm/.test(unitCode || '')) return v / 2.54;
  if (/wmoUnit:m/.test(unitCode || '')) return v * 39.3701;
  return v;
}

function formatSnow(amount) {
  if (!amount || amount <= 0) return '-';
  const formatted = amount.toFixed(1);
  return formatted.endsWith('.0') ? `${formatted.slice(0, -2)}"` : `${formatted}"`;
}

function formatTime(localIso) {
  if (!localIso) return '';
  const d = new Date(localIso);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }).replace(' AM', 'a').replace(' PM', 'p');
}

async function fetchJson(url, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), HA_TIMEOUT_MS);
  const res = await fetch(url, { ...options, signal: controller.signal }).finally(() => clearTimeout(timeout));
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Request failed ${res.status}: ${text}`);
  }
  return res.json();
}

async function fetchHa(path, options = {}) {
  if (!HA_TOKEN || HA_TOKEN === 'REPLACE_WITH_HA_TOKEN') {
    throw new Error('Home Assistant token is not set in jobs/tomorrow.js');
  }
  return fetchJson(`${HA_BASE_URL}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${HA_TOKEN}`,
      'Content-Type': 'application/json'
    }
  });
}

async function getForecast() {
  const body = JSON.stringify({ entity_id: FORECAST_ENTITY, type: 'daily' });
  const url = `${HA_BASE_URL}/api/services/weather/get_forecasts?return_response`;
  const data = await fetchHa('/api/services/weather/get_forecasts?return_response', {
    method: 'POST',
    body
  });
  return data?.service_response?.[FORECAST_ENTITY]?.forecast ?? [];
}

async function getPollen() {
  if (!POLLEN_API_KEY) {
    return { tree: '❌', grass: '❌', weed: '❌' };
  }
  try {
    const url = `https://pollen.googleapis.com/v1/forecast:lookup?key=${POLLEN_API_KEY}&location.longitude=-73.9223422&location.latitude=42.731868&days=1`;
    const data = await fetchJson(url);
    const info = data?.dailyInfo?.[0]?.pollenTypeInfo;
    if (!info) return { tree: '❌', grass: '❌', weed: '❌' };
    const findLevel = code => info.find(entry => entry.code === code)?.indexInfo?.category || 'n/a';
    return {
      tree: arrowFor(findLevel('TREE')),
      grass: arrowFor(findLevel('GRASS')),
      weed: arrowFor(findLevel('WEED'))
    };
  } catch (error) {
    console.error('[tomorrow] Skipping pollen', error);
    return { tree: '❌', grass: '❌', weed: '❌' };
  }
}

async function getSunTimes() {
  const data = await fetchHa('/api/states/sun.sun');
  const sunrise = formatTime(data?.attributes?.next_rising);
  const sunset = formatTime(data?.attributes?.next_setting);
  return { sunrise, sunset };
}

async function getSnowByDate() {
  try {
    const data = await fetchJson(SNOW_URL, {
      headers: {
        'user-agent': 'dashboard (dasutin@gmail.com)',
        accept: 'application/geo+json'
      }
    });
    const values = data?.properties?.snowfallAmount?.values || [];
    const unitCode = data?.properties?.snowfallAmount?.uom;
    const map = {};
    values.forEach(entry => {
      const value = inchesFrom(entry?.value, entry?.unitCode || unitCode);
      const valid = entry?.validTime?.split('/')?.[0];
      if (!value || !valid) return;
      const date = new Date(valid);
      if (Number.isNaN(date.getTime())) return;
      const key = date.toISOString().slice(0, 10);
      map[key] = (map[key] || 0) + value;
    });
    return map;
  } catch (error) {
    console.error('[tomorrow] Skipping NWS snow data', error);
    return {};
  }
}

export default {
  interval: 30 * 60 * 1000,
  widgetId: 'tomorrow',
  type: 'tomorrow',
  run: async emit => {
    try {
      const [forecast, pollen, sunTimes, snowByDate] = await Promise.all([
        getForecast(),
        getPollen(),
        getSunTimes(),
        getSnowByDate()
      ]);

      const payload = {
        tree_level: pollen.tree,
        grass_level: pollen.grass,
        weed_level: pollen.weed,
        sunrise: sunTimes.sunrise,
        sunset: sunTimes.sunset
      };

      for (let i = 0; i < 6; i += 1) {
        const f = forecast[i];
        if (!f) continue;
        const idx = i + 1;
        const dateIso = f.datetime;
        const date = dateIso ? new Date(dateIso) : null;
        const day = date && !Number.isNaN(date.getTime()) ? date.toLocaleDateString('en-US', { weekday: 'short' }) : '';
        const temp = Math.round(Number(f.temperature ?? NaN));
        const low = Math.round(Number(f.templow ?? NaN));
        const cond = emojiFor(f.condition);
        const snowKey = date ? date.toISOString().slice(0, 10) : '';
        const snowAmt = snowKey && snowByDate[snowKey] ? snowByDate[snowKey] : 0;

        payload[`day${idx}`] = day;
        payload[`condition${idx}`] = cond;
        payload[`temp${idx}`] = Number.isFinite(temp) ? temp : '';
        payload[`low${idx}`] = Number.isFinite(low) ? low : '';
        payload[`temp${idx}_class`] = Number.isFinite(temp) ? tempClass(temp) : '';
        payload[`low${idx}_class`] = Number.isFinite(low) ? tempClass(low) : '';
        payload[`snow${idx}`] = formatSnow(snowAmt);
      }

      emit({ widgetId: 'tomorrow', type: 'tomorrow', data: payload });
    } catch (error) {
      console.error('tomorrow job failed', error);
      emit({ widgetId: 'tomorrow', type: 'tomorrow', data: { error: String(error) } });
    }
  }
};
