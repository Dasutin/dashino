const HA_BASE_URL = process.env.HA_BASE_URL || 'http://localhost:8123';
const HA_TOKEN = process.env.HA_TOKEN || 'REPLACE_WITH_HA_TOKEN';
const HA_TIMEOUT_MS = 5000;
const FORECAST_ENTITY = 'weather.tomorrow_io_home_daily';

function emojiForCondition(condition) {
  const c = (condition || '').toLowerCase();
  if (c === 'sunny' || c === 'clear-day') return '☀️';
  if (c === 'clear-night') return '🌕';
  if (c === 'cloudy') return '☁️';
  if (c === 'partlycloudy' || c === 'partly-cloudy-day' || c === 'partly-cloudy-night') return '⛅';
  if (c === 'rainy' || c === 'rain') return '🌧️';
  if (c === 'pouring') return '💧';
  if (c === 'snowy' || c === 'snow') return '❄️';
  if (c === 'fog') return '🌫️';
  if (c === 'windy') return '💨';
  if (c === 'hail' || c === 'snowy-rainy') return '🌨️';
  if (c === 'lightning' || c === 'lightning-rainy' || c === 'thunderstorm') return '🌩️';
  return '🔍';
}

function formatHour(localIso) {
  if (!localIso) return '';
  const d = new Date(localIso);
  if (Number.isNaN(d.getTime())) return '';
  const hour24 = d.getHours();
  const hour12 = ((hour24 + 11) % 12) + 1;
  const suffix = hour24 >= 12 ? 'p' : 'a';
  return `${hour12}${suffix}`;
}

async function fetchHourlyForecast() {
  if (!HA_TOKEN || HA_TOKEN === 'REPLACE_WITH_HA_TOKEN') {
    throw new Error('Home Assistant token is not set in jobs/hourly.js');
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), HA_TIMEOUT_MS);

  const res = await fetch(`${HA_BASE_URL}/api/services/weather/get_forecasts?return_response`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${HA_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ entity_id: FORECAST_ENTITY, type: 'hourly' }),
    signal: controller.signal
  }).finally(() => clearTimeout(timeout));

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HA request failed (${res.status}): ${text}`);
  }

  const data = await res.json();
  return data?.service_response?.[FORECAST_ENTITY]?.forecast || [];
}

function buildPoints(hourly) {
  const everyOther = hourly.filter((_, index) => index % 2 === 0).slice(0, 12);
  return everyOther.map(entry => {
    const temp = Math.round(Number(entry?.temperature ?? NaN));
    return {
      hour: formatHour(entry?.datetime),
      temp: Number.isFinite(temp) ? temp.toString() : '',
      emoji: emojiForCondition(entry?.condition)
    };
  });
}

export default {
  interval: 60_000,
  widgetId: 'hourly',
  type: 'hourly',
  run: async emit => {
    try {
      const hourly = await fetchHourlyForecast();
      const points = buildPoints(hourly);
      emit({ widgetId: 'hourly', type: 'hourly', data: { points } });
    } catch (error) {
      console.error('hourly job failed', error);
      emit({ widgetId: 'hourly', type: 'hourly', data: { error: String(error) } });
    }
  }
};
