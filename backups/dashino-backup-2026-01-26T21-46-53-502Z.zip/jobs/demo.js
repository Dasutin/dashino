export default {
  interval: 60000,
  async run() {
    // No-op placeholder; demos are driven by jobs/message.js and jobs/metric.js
  }
};
