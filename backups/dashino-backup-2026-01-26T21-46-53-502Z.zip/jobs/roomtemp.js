const HA_BASE_URL = process.env.HA_BASE_URL || 'http://localhost:8123';
const HA_TOKEN = process.env.HA_TOKEN || 'REPLACE_WITH_HA_TOKEN';
const HA_TIMEOUT_MS = 5000;
let cachedData = null;

const SENSORS = [
  { key: 'dustin_office', name: "Dustin's Office", temp: 'sensor.dustins_office_temp_air_temperature', humidity: 'sensor.dustins_office_temp_humidity' },
  { key: 'basement', name: 'Basement', temp: 'sensor.basement_temp_sensor_air_temperature', humidity: 'sensor.basement_temp_sensor_humidity' },
  { key: 'master_bedroom', name: 'Master Bedroom', temp: 'sensor.master_bedroom_temp_sensor_air_temperature', humidity: 'sensor.master_bedroom_temp_sensor_humidity' },
  { key: 'ryan_room', name: "Ryan's Room", temp: 'sensor.temperature_humidity_xs_sensor_air_temperature', humidity: 'sensor.temperature_humidity_xs_sensor_humidity' }
];

const OUTSIDE = { temp: 'sensor.outside_temperature_sensor_air_temperature', humidity: 'sensor.outside_temperature_sensor_humidity' };

async function fetchState(entityId) {
  if (!HA_TOKEN || HA_TOKEN === 'REPLACE_WITH_HA_TOKEN') {
    throw new Error('Home Assistant token is not set in jobs/roomtemp.js');
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), HA_TIMEOUT_MS);

  const res = await fetch(`${HA_BASE_URL}/api/states/${encodeURIComponent(entityId)}`, {
    headers: {
      Authorization: `Bearer ${HA_TOKEN}`,
      'Content-Type': 'application/json'
    },
    signal: controller.signal
  }).finally(() => clearTimeout(timeout));

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HA request failed (${res.status}): ${text}`);
  }

  const json = await res.json();
  return Number(json?.state ?? NaN);
}

export default {
  interval: 20_000,
  widgetId: 'roomtemp',
  type: 'roomtemp',
  run: async emit => {
    if (cachedData) {
      emit({ widgetId: 'roomtemp', type: 'roomtemp', data: cachedData });
    }

    try {
      const rooms = await Promise.all(
        SENSORS.map(async sensor => {
          const [temp, humidity] = await Promise.all([
            fetchState(sensor.temp),
            fetchState(sensor.humidity)
          ]);
          return { name: sensor.name, temp, humidity };
        })
      );

      const [outsideTemp, outsideHumidity] = await Promise.all([
        fetchState(OUTSIDE.temp),
        fetchState(OUTSIDE.humidity)
      ]);

      const fmtTemp = v => (Number.isFinite(v) ? `${Math.round(v)}°` : '—');
      const fmtHum = v => (Number.isFinite(v) ? `${Math.round(v)}%` : '—');

      const office = rooms.find(r => r.name === "Dustin's Office");
      const basement = rooms.find(r => r.name === 'Basement');
      const master = rooms.find(r => r.name === 'Master Bedroom');
      const ryan = rooms.find(r => r.name === "Ryan's Room");

      cachedData = {
        rooms,
        outside: { temp: outsideTemp, humidity: outsideHumidity },
        dustinofficetemp: fmtTemp(office?.temp),
        dustinofficehumid: fmtHum(office?.humidity),
        basementtemp: fmtTemp(basement?.temp),
        basementhumid: fmtHum(basement?.humidity),
        masterbedroomtemp: fmtTemp(master?.temp),
        masterbedroomhumid: fmtHum(master?.humidity),
        ryanroomtemp: fmtTemp(ryan?.temp),
        ryanroomhumid: fmtHum(ryan?.humidity),
        fetchedAt: new Date().toISOString()
      };

      emit({ widgetId: 'roomtemp', type: 'roomtemp', data: cachedData });
    } catch (error) {
      console.error('roomtemp job failed', error);
      emit({ widgetId: 'roomtemp', type: 'roomtemp', data: { error: String(error) } });
    }
  }
};
