const HA_BASE_URL = process.env.HA_BASE_URL || 'http://localhost:8123';
const HA_TOKEN = process.env.HA_TOKEN || 'REPLACE_WITH_HA_TOKEN';
const HA_TIMEOUT_MS = 5000;

const STOCKS = ['orcl', 'aapl', 'nvda', 'msft', 'amzn', 'tsla', 'btc_usd', 'eth_usd'];
const SHIB_SENSOR = 'sensor.shib_exchange_rate';
const SHIB_HOLDINGS = 1_509_621.25143;

function formatValue(value) {
  const num = Number(value);
  if (!Number.isFinite(num)) return '';
  if (Math.abs(num) >= 1000) return `${(num / 1000).toFixed(1)}K`;
  return num.toFixed(2);
}

async function fetchHaState(entityId) {
  if (!HA_TOKEN || HA_TOKEN === 'REPLACE_WITH_HA_TOKEN') {
    throw new Error('Home Assistant token is not set in jobs/stocks.js');
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), HA_TIMEOUT_MS);

  const res = await fetch(`${HA_BASE_URL}/api/states/${encodeURIComponent(entityId)}`, {
    headers: {
      Authorization: `Bearer ${HA_TOKEN}`,
      'Content-Type': 'application/json'
    },
    signal: controller.signal
  }).finally(() => clearTimeout(timeout));

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HA request failed (${res.status}): ${text}`);
  }

  return res.json();
}

export default {
  interval: 60_000,
  widgetId: 'stocks',
  type: 'stocks',
  run: async emit => {
    try {
      const payload = {};

      const stockPromises = STOCKS.map(async (symbol, index) => {
        const data = await fetchHaState(`sensor.yahoofinance_${symbol}`);
        const price = data?.state;
        const change = data?.attributes?.regularMarketChange;
        if (price === undefined || change === undefined) return;

        const displaySymbol = symbol === 'btc_usd' ? 'BTC' : symbol === 'eth_usd' ? 'ETH' : symbol.toUpperCase();
        const slot = index + 1;
        payload[`symbol${slot}`] = displaySymbol;
        payload[`price${slot}`] = formatValue(price);
        payload[`change${slot}`] = formatValue(change);
        payload[`change${slot}_class`] = Number(change) >= 0 ? 'pos' : 'neg';
      });

      await Promise.all(stockPromises);

      const shibData = await fetchHaState(SHIB_SENSOR);
      const shibPrice = Number(shibData?.state ?? NaN);
      const shibTotal = shibPrice * SHIB_HOLDINGS;
      const shibIndex = STOCKS.length + 1;
      payload[`symbol${shibIndex}`] = 'SHIB';
      payload[`price${shibIndex}`] = formatValue(shibTotal);
      payload[`change${shibIndex}`] = '';
      payload[`change${shibIndex}_class`] = '';

      emit({ widgetId: 'stocks', type: 'stocks', data: payload });
    } catch (error) {
      console.error('stocks job failed', error);
      emit({ widgetId: 'stocks', type: 'stocks', data: { error: String(error) } });
    }
  }
};
