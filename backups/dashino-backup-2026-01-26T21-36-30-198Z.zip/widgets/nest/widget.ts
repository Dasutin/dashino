import type { StreamPayload, WidgetController, WidgetFactory } from '../../web/src/types';

type NestCurrent = {
  temp?: number;
  target?: number;
  humidity?: number;
  hvac_state?: string;
  percent?: number;
};

const CHART_JS_CDN = 'https://cdn.jsdelivr.net/npm/chart.js';
let chartReadyPromise: Promise<void> | null = null;
const GAUGE_COLOR = '#4ade80';

declare global {
  interface Window {
    Chart?: any;
  }
}

type NestData = {
  current?: NestCurrent;
  error?: string;
};

export const createNestController: WidgetFactory = ({ root, widget }) => {
  return new NestController(root, widget.id);
};

export default createNestController;

type NestState = 'heating' | 'cooling' | 'idle';

class NestController implements WidgetController {
  private root: HTMLElement;
  private container: HTMLElement | null;
  private meterCanvas: HTMLCanvasElement | null;
  private meterValue: HTMLElement | null;
  private meterLabel: HTMLElement | null;
  private targetEl: HTMLElement | null;
  private errorEl: HTMLElement | null;
  private chart: any = null;

  constructor(root: HTMLElement, widgetId: string) {
    this.root = root;
    this.container = root.querySelector('.widget-nest');
    this.meterCanvas = root.querySelector('.meter-chart');
    this.meterValue = root.querySelector('.meter-value');
    this.meterLabel = root.querySelector('.meter-label');
    this.targetEl = root.querySelector('.meta .target span');
    this.errorEl = root.querySelector('.error');
  }

  update(payload?: StreamPayload) {
    const data = (payload?.data ?? payload ?? {}) as NestData;
    const current = data.current || {};

    const temp = Number(current.temp ?? NaN);
    const target = Number(current.target ?? NaN);
    const percentFromPayload = Number.isFinite(current.percent) ? Number(current.percent) : NaN;
    const percentFromTemp = this.toPercent(temp);
    const percent = Number.isFinite(percentFromPayload)
      ? this.clampPercent(percentFromPayload)
      : this.clampPercent(percentFromTemp);
    const hvacState = this.normalizeState((current.hvac_state || 'idle').toString());

    this.setStateClass(hvacState);
    this.updateMeter(percent, temp, target, hvacState);

    if (this.targetEl) this.targetEl.textContent = Number.isFinite(target) ? String(Math.round(target)) : '--';
    if (this.errorEl) this.errorEl.textContent = data.error ? String(data.error) : '';
  }

  destroy() {
    try {
      this.chart?.destroy?.();
    } catch (_) {
      /* noop */
    }
  }

  private setStateClass(state: NestState) {
    const target = this.container ?? this.root;
    const classList = target.classList;
    Array.from(classList)
      .filter(cls => cls.startsWith('nest-state-'))
      .forEach(cls => classList.remove(cls));
    if (!classList.contains('widget-nest')) classList.add('widget-nest');
    classList.add(`nest-state-${state}`);
  }

  private updateMeter(percent: number, temp: number, target: number, state: NestState) {
    if (this.meterValue) this.meterValue.textContent = Number.isFinite(temp) ? `${Math.round(temp)}°` : '--°';
    if (this.meterLabel) this.meterLabel.textContent = Number.isFinite(target) ? `target ${Math.round(target)}°` : 'target --°';
    if (typeof window.Chart === 'undefined') {
      void this.ensureChartReady().then(() => this.updateChart(percent, state));
      return;
    }
    this.updateChart(percent, state);
  }

  private toPercent(value: number): number {
    // Map thermostat range 40-100 to 0-100% for the arc
    if (!Number.isFinite(value)) return NaN;
    return ((value - 40) / 60) * 100;
  }

  private clampPercent(value: number): number {
    if (!Number.isFinite(value)) return 0;
    return Math.min(100, Math.max(0, value));
  }
  private colorForState(state: NestState) {
    // Align with EV meter green for a consistent look regardless of state.
    return GAUGE_COLOR;
  }

  private normalizeState(state: string): NestState {
    if (state === 'heating') return 'heating';
    if (state === 'cooling') return 'cooling';
    return 'idle';
  }

  private async ensureChartReady(): Promise<void> {
    if (typeof window.Chart !== 'undefined') return;
    if (!chartReadyPromise) {
      chartReadyPromise = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = CHART_JS_CDN;
        script.async = true;
        script.onload = () => resolve();
        script.onerror = err => reject(err);
        document.head.appendChild(script);
      });
    }
    await chartReadyPromise;
  }

  private updateChart(percent: number, state: NestState) {
    const canvas = this.meterCanvas as HTMLCanvasElement | null;
    if (!canvas || typeof window.Chart === 'undefined') return;

    const normalized = Number.isFinite(percent) ? Math.max(0, Math.min(100, percent)) : 0;
    const color = this.colorForState(state);
    const track = 'rgba(255, 255, 255, 0.08)';

    if (!this.chart) {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      this.chart = new window.Chart(ctx, {
        type: 'doughnut',
        data: {
          datasets: [
            {
              data: [normalized, 100 - normalized],
              backgroundColor: [color, track],
              borderWidth: 0,
              borderRadius: 10,
              cutout: '82%'
            }
          ]
        },
        options: {
          animation: true,
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: { enabled: false }
          },
          rotation: -120,
          circumference: 240
        }
      });
      return;
    }

    const dataset = this.chart.data?.datasets?.[0];
    if (dataset) {
      dataset.data = [normalized, 100 - normalized];
      dataset.backgroundColor = [color, track];
    }
    this.chart.update('none');
  }
}
