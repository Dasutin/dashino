import type { StreamPayload, WidgetController, WidgetFactory } from '../../web/src/types';

type Bindable = HTMLElement & { dataset: { bind?: string; bindClass?: string } };

export const createTomorrowController: WidgetFactory = ({ root }) => {
  return new TomorrowController(root);
};

class TomorrowController implements WidgetController {
  private root: HTMLElement;

  constructor(root: HTMLElement) {
    this.root = root;
  }

  update(payload?: StreamPayload) {
    const data = (payload?.data ?? payload ?? {}) as Record<string, unknown>;
    this.bindText(data);
    this.bindClasses(data);
  }

  destroy() {
    // no-op
  }

  private bindText(data: Record<string, unknown>) {
    const nodes = this.root.querySelectorAll('[data-bind]');
    nodes.forEach(node => {
      const el = node as Bindable;
      const key = el.dataset.bind;
      if (!key) return;
      const value = data[key];
      if (value === undefined || value === null) return;
      el.textContent = String(value);
    });
  }

  private bindClasses(data: Record<string, unknown>) {
    const nodes = this.root.querySelectorAll('[data-bind-class]');
    nodes.forEach(node => {
      const el = node as Bindable;
      const key = el.dataset.bindClass;
      if (!key) return;
      const className = data[key];
      if (!className) return;
      const classes = String(className)
        .split(/\s+/)
        .filter(Boolean);
      // remove previous temp-* classes
      el.classList.forEach(cls => {
        if (cls.startsWith('temp-')) el.classList.remove(cls);
      });
      classes.forEach(c => el.classList.add(c));
    });
  }
}
