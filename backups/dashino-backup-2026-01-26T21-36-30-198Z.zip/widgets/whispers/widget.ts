// Whispers widget script placeholder.
export {};
