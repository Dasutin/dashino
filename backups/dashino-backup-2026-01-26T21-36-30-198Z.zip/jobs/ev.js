const HA_BASE_URL = process.env.HA_BASE_URL || 'http://localhost:8123';
const HA_TOKEN = process.env.HA_TOKEN || 'REPLACE_WITH_HA_TOKEN';
const HA_TIMEOUT_MS = 5000;

const EV_BATTERY_ENTITY = 'sensor.fordpass_1ft6w3l75swg02458_elveh';
const EV_CHARGING_ENTITY = 'sensor.fordpass_1ft6w3l75swg02458_elvehcharging';

async function fetchHaState(entityId) {
  if (!HA_TOKEN || HA_TOKEN === 'REPLACE_WITH_HA_TOKEN') {
    throw new Error('Home Assistant token is not set in jobs/ev.js');
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), HA_TIMEOUT_MS);

  const res = await fetch(`${HA_BASE_URL}/api/states/${encodeURIComponent(entityId)}`, {
    headers: {
      Authorization: `Bearer ${HA_TOKEN}`,
      'Content-Type': 'application/json'
    },
    signal: controller.signal
  }).finally(() => clearTimeout(timeout));

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HA request failed (${res.status}): ${text}`);
  }

  return res.json();
}

function resolveState(chargingStatus, plugStatus) {
  if (!chargingStatus) return 'unknown';
  if (chargingStatus === 'IN_PROGRESS') return 'charging';
  if (chargingStatus === 'NOT_READY') return plugStatus === 'CONNECTED' ? 'connected' : 'unplugged';
  if (chargingStatus === 'COMPLETED') return 'idle';
  return 'unknown';
}

function formatTime(iso) {
  if (!iso) return null;
  const parsed = new Date(iso);
  if (Number.isNaN(parsed.getTime())) return null;
  const now = new Date();
  const hoursFromNow = Math.round((parsed.getTime() - now.getTime()) / 3_600_000);
  const formatted = parsed.toLocaleString([], { hour: 'numeric', minute: '2-digit', weekday: 'short' });
  if (hoursFromNow >= 0) return `${formatted} (${hoursFromNow} hrs)`;
  return `${formatted} (${Math.abs(hoursFromNow)} hours ago)`;
}

export default {
  interval: 60_000,
  widgetId: 'ev',
  type: 'ev',
  run: async emit => {
    try {
      const [batteryState, chargingState] = await Promise.all([
        fetchHaState(EV_BATTERY_ENTITY),
        fetchHaState(EV_CHARGING_ENTITY)
      ]);

      const battery = Number(batteryState?.attributes?.batteryCharge ?? NaN);
      const range = Number(batteryState?.state ?? NaN);
      const chargingStatus = chargingState?.attributes?.chargingStatus;
      const plugStatus = chargingState?.attributes?.plugStatus;
      const estimatedEnd = chargingState?.attributes?.estimatedEndTime;

      const state = resolveState(chargingStatus, plugStatus);
      const time = state === 'charging' && Number.isFinite(battery) && battery < 100 ? formatTime(estimatedEnd) : null;

      const data = {
        battery: Number.isFinite(battery) ? Math.round(battery) : undefined,
        current: Number.isFinite(range) ? `${Math.round(range)} mi` : undefined,
        time,
        state
      };

      emit({ widgetId: 'ev', type: 'ev', data });
    } catch (error) {
      console.error('ev job failed', error);
      emit({ widgetId: 'ev', type: 'ev', data: { error: String(error) } });
    }
  }
};
