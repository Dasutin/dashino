const HA_BASE_URL = process.env.HA_BASE_URL || 'http://localhost:8123';
const HA_TOKEN = process.env.HA_TOKEN || 'REPLACE_WITH_HA_TOKEN';
const HA_TIMEOUT_MS = 8000;

let cachedCurrent = null;
let cachedAt = null;

async function fetchHaState(entityId) {
  if (!HA_TOKEN || HA_TOKEN === 'REPLACE_WITH_HA_TOKEN') {
    throw new Error('Home Assistant token is not set in jobs/forecast.js');
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), HA_TIMEOUT_MS);

  const res = await fetch(`${HA_BASE_URL}/api/states/${encodeURIComponent(entityId)}`, {
    headers: {
      Authorization: `Bearer ${HA_TOKEN}`,
      'Content-Type': 'application/json'
    },
    signal: controller.signal
  }).finally(() => clearTimeout(timeout));

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HA request failed (${res.status}): ${text}`);
  }

  return res.json();
}

export default {
  interval: 15_000,
  widgetId: 'forecast',
  type: 'forecast',
  run: async emit => {
    try {
      if (cachedCurrent) {
        emit({
          widgetId: 'forecast',
          type: 'forecast',
          data: { current: cachedCurrent, cached: true, fetchedAt: cachedAt }
        });
      }

      const [tomorrowWeather, outsideTemp, outsideDewPoint] = await Promise.all([
        fetchHaState('weather.tomorrow_io_home_daily'),
        fetchHaState('sensor.outside_temperature_sensor_air_temperature'),
        fetchHaState('sensor.outside_temperature_sensor_dew_point')
      ]);

      const current = {
        temperature: Math.round(Number(outsideTemp?.state ?? NaN)),
        dew_point: Math.round(Number(outsideDewPoint?.state ?? NaN)),
        wind_speed: tomorrowWeather?.attributes?.wind_speed ?? null,
        wind_bearing: tomorrowWeather?.attributes?.wind_bearing ?? null,
        summary: String(tomorrowWeather?.state ?? '').replace(/^\s+|\s+$/g, '')
      };

      cachedCurrent = current;
      cachedAt = new Date().toISOString();

      emit({
        widgetId: 'forecast',
        type: 'forecast',
        data: { current, cached: false, fetchedAt: cachedAt }
      });
    } catch (error) {
      console.error('forecast job failed', error);
      emit({
        widgetId: 'forecast',
        type: 'forecast',
        data: {
          error: String(error),
          current: cachedCurrent ?? undefined,
          cached: Boolean(cachedCurrent),
          fetchedAt: cachedAt
        }
      });
    }
  }
};
