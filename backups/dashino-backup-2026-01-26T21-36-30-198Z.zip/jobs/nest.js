const HA_BASE_URL = process.env.HA_BASE_URL || 'http://localhost:8123';
const HA_TOKEN = process.env.HA_TOKEN || 'REPLACE_WITH_HA_TOKEN';
const HA_TIMEOUT_MS = 8000;

async function fetchNestState() {
  if (!HA_TOKEN || HA_TOKEN === 'REPLACE_WITH_HA_TOKEN') {
    throw new Error('Home Assistant token is not set in jobs/nest.js');
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), HA_TIMEOUT_MS);

  const res = await fetch(`${HA_BASE_URL}/api/states/climate.thermostat`, {
    headers: {
      Authorization: `Bearer ${HA_TOKEN}`,
      'Content-Type': 'application/json'
    },
    signal: controller.signal
  }).finally(() => clearTimeout(timeout));

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HA request failed (${res.status}): ${text}`);
  }

  return res.json();
}

export default {
  interval: 15_000,
  widgetId: 'nest',
  type: 'nest',
  run: async emit => {
    try {
      const nest = await fetchNestState();
      const attrs = nest?.attributes ?? {};

      const target = Number(attrs.temperature ?? NaN);
      const temp = Number(attrs.current_temperature ?? NaN);
      const hvac_action = String(attrs.hvac_action ?? '').toLowerCase();
      const hvac_state = hvac_action === 'cooling' || hvac_action === 'heating' ? hvac_action : 'idle';

      const percent = Math.min(Math.max(((temp - 50) / 40) * 100, 0), 100);
      const now = new Date();

      emit({
        widgetId: 'nest',
        type: 'nest',
        data: {
          current: {
            temp,
            target,
            hvac_state,
            percent
          },
          fetchedAt: now.toISOString()
        }
      });
    } catch (error) {
      console.error('nest job failed', error);
      emit({ widgetId: 'nest', type: 'nest', data: { error: String(error) } });
    }
  }
};
